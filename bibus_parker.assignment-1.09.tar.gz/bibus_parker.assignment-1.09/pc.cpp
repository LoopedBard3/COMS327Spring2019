#include <cstdlib>
#include <cstring>
#include <ncurses.h>

#include "dungeon.h"
#include "pc.h"
#include "utils.h"
#include "move.h"
#include "path.h"
#include "io.h"
#include "object.h"

//Setup enums for finding the items in the players equipped slots
#define equipable_lu_entry(name) \
  {                              \
#name, location_##name       \
  }
static const struct
{
  const char *name;
  const uint32_t value;
} equipable_lookup[] = {
    equipable_lu_entry(WEAPON),
    equipable_lu_entry(OFFHAND),
    equipable_lu_entry(RANGED),
    equipable_lu_entry(ARMOR),
    equipable_lu_entry(HELMET),
    equipable_lu_entry(CLOAK),
    equipable_lu_entry(GLOVES),
    equipable_lu_entry(BOOTS),
    equipable_lu_entry(AMULET),
    equipable_lu_entry(LIGHT),
    equipable_lu_entry(LRING),
    equipable_lu_entry(RRING),
    {0, 0}};

uint32_t pc_is_alive(dungeon *d)
{
  return d->PC->alive;
}

void place_pc(dungeon *d)
{
  d->PC->position[dim_y] = rand_range(d->rooms->position[dim_y],
                                      (d->rooms->position[dim_y] +
                                       d->rooms->size[dim_y] - 1));
  d->PC->position[dim_x] = rand_range(d->rooms->position[dim_x],
                                      (d->rooms->position[dim_x] +
                                       d->rooms->size[dim_x] - 1));

  pc_init_known_terrain(d->PC);
  pc_observe_terrain(d->PC, d);
}

void config_pc(dungeon *d)
{
  static dice pc_dice(0, 1, 4);

  d->PC = new pc;

  d->PC->symbol = '@';

  place_pc(d);

  d->PC->speed = PC_SPEED;
  d->PC->hp = PC_HITPOINTS;
  d->PC->alive = 1;
  d->PC->sequence_number = 0;
  d->PC->kills[kill_direct] = d->PC->kills[kill_avenged] = 0;
  d->PC->color.push_back(COLOR_WHITE);
  d->PC->damage = &pc_dice;
  d->PC->name = "Isabella Garcia-Shapiro";

  d->character_map[d->PC->position[dim_y]][d->PC->position[dim_x]] = d->PC;

  dijkstra(d);
  dijkstra_tunnel(d);
}

uint32_t pc_next_pos(dungeon *d, pair_t dir)
{
  static uint32_t have_seen_corner = 0;
  static uint32_t count = 0;

  dir[dim_y] = dir[dim_x] = 0;

  if (in_corner(d, d->PC))
  {
    if (!count)
    {
      count = 1;
    }
    have_seen_corner = 1;
  }

  /* First, eat anybody standing next to us. */
  if (charxy(d->PC->position[dim_x] - 1, d->PC->position[dim_y] - 1))
  {
    dir[dim_y] = -1;
    dir[dim_x] = -1;
  }
  else if (charxy(d->PC->position[dim_x], d->PC->position[dim_y] - 1))
  {
    dir[dim_y] = -1;
  }
  else if (charxy(d->PC->position[dim_x] + 1, d->PC->position[dim_y] - 1))
  {
    dir[dim_y] = -1;
    dir[dim_x] = 1;
  }
  else if (charxy(d->PC->position[dim_x] - 1, d->PC->position[dim_y]))
  {
    dir[dim_x] = -1;
  }
  else if (charxy(d->PC->position[dim_x] + 1, d->PC->position[dim_y]))
  {
    dir[dim_x] = 1;
  }
  else if (charxy(d->PC->position[dim_x] - 1, d->PC->position[dim_y] + 1))
  {
    dir[dim_y] = 1;
    dir[dim_x] = -1;
  }
  else if (charxy(d->PC->position[dim_x], d->PC->position[dim_y] + 1))
  {
    dir[dim_y] = 1;
  }
  else if (charxy(d->PC->position[dim_x] + 1, d->PC->position[dim_y] + 1))
  {
    dir[dim_y] = 1;
    dir[dim_x] = 1;
  }
  else if (!have_seen_corner || count < 250)
  {
    /* Head to a corner and let most of the NPCs kill each other off */
    if (count)
    {
      count++;
    }
    if (!against_wall(d, d->PC) && ((rand() & 0x111) == 0x111))
    {
      dir[dim_x] = (rand() % 3) - 1;
      dir[dim_y] = (rand() % 3) - 1;
    }
    else
    {
      dir_nearest_wall(d, d->PC, dir);
    }
  }
  else
  {
    /* And after we've been there, let's head toward the center of the map. */
    if (!against_wall(d, d->PC) && ((rand() & 0x111) == 0x111))
    {
      dir[dim_x] = (rand() % 3) - 1;
      dir[dim_y] = (rand() % 3) - 1;
    }
    else
    {
      dir[dim_x] = ((d->PC->position[dim_x] > DUNGEON_X / 2) ? -1 : 1);
      dir[dim_y] = ((d->PC->position[dim_y] > DUNGEON_Y / 2) ? -1 : 1);
    }
  }

  /* Don't move to an unoccupied location if that places us next to a monster */
  if (!charxy(d->PC->position[dim_x] + dir[dim_x],
              d->PC->position[dim_y] + dir[dim_y]) &&
      ((charxy(d->PC->position[dim_x] + dir[dim_x] - 1,
               d->PC->position[dim_y] + dir[dim_y] - 1) &&
        (charxy(d->PC->position[dim_x] + dir[dim_x] - 1,
                d->PC->position[dim_y] + dir[dim_y] - 1) != d->PC)) ||
       (charxy(d->PC->position[dim_x] + dir[dim_x] - 1,
               d->PC->position[dim_y] + dir[dim_y]) &&
        (charxy(d->PC->position[dim_x] + dir[dim_x] - 1,
                d->PC->position[dim_y] + dir[dim_y]) != d->PC)) ||
       (charxy(d->PC->position[dim_x] + dir[dim_x] - 1,
               d->PC->position[dim_y] + dir[dim_y] + 1) &&
        (charxy(d->PC->position[dim_x] + dir[dim_x] - 1,
                d->PC->position[dim_y] + dir[dim_y] + 1) != d->PC)) ||
       (charxy(d->PC->position[dim_x] + dir[dim_x],
               d->PC->position[dim_y] + dir[dim_y] - 1) &&
        (charxy(d->PC->position[dim_x] + dir[dim_x],
                d->PC->position[dim_y] + dir[dim_y] - 1) != d->PC)) ||
       (charxy(d->PC->position[dim_x] + dir[dim_x],
               d->PC->position[dim_y] + dir[dim_y] + 1) &&
        (charxy(d->PC->position[dim_x] + dir[dim_x],
                d->PC->position[dim_y] + dir[dim_y] + 1) != d->PC)) ||
       (charxy(d->PC->position[dim_x] + dir[dim_x] + 1,
               d->PC->position[dim_y] + dir[dim_y] - 1) &&
        (charxy(d->PC->position[dim_x] + dir[dim_x] + 1,
                d->PC->position[dim_y] + dir[dim_y] - 1) != d->PC)) ||
       (charxy(d->PC->position[dim_x] + dir[dim_x] + 1,
               d->PC->position[dim_y] + dir[dim_y]) &&
        (charxy(d->PC->position[dim_x] + dir[dim_x] + 1,
                d->PC->position[dim_y] + dir[dim_y]) != d->PC)) ||
       (charxy(d->PC->position[dim_x] + dir[dim_x] + 1,
               d->PC->position[dim_y] + dir[dim_y] + 1) &&
        (charxy(d->PC->position[dim_x] + dir[dim_x] + 1,
                d->PC->position[dim_y] + dir[dim_y] + 1) != d->PC))))
  {
    dir[dim_x] = dir[dim_y] = 0;
  }

  return 0;
}

uint32_t pc_in_room(dungeon *d, uint32_t room)
{
  if ((room < d->num_rooms) &&
      (d->PC->position[dim_x] >= d->rooms[room].position[dim_x]) &&
      (d->PC->position[dim_x] < (d->rooms[room].position[dim_x] +
                                 d->rooms[room].size[dim_x])) &&
      (d->PC->position[dim_y] >= d->rooms[room].position[dim_y]) &&
      (d->PC->position[dim_y] < (d->rooms[room].position[dim_y] +
                                 d->rooms[room].size[dim_y])))
  {
    return 1;
  }

  return 0;
}

void pc_learn_terrain(pc *p, pair_t pos, terrain_type ter)
{
  p->known_terrain[pos[dim_y]][pos[dim_x]] = ter;
  p->visible[pos[dim_y]][pos[dim_x]] = 1;
}

void pc_reset_visibility(pc *p)
{
  uint32_t y, x;

  for (y = 0; y < DUNGEON_Y; y++)
  {
    for (x = 0; x < DUNGEON_X; x++)
    {
      p->visible[y][x] = 0;
    }
  }
}

terrain_type pc_learned_terrain(pc *p, int16_t y, int16_t x)
{
  if (y < 0 || y >= DUNGEON_Y || x < 0 || x >= DUNGEON_X)
  {
    io_queue_message("Invalid value to %s: %d, %d", __FUNCTION__, y, x);
  }

  return p->known_terrain[y][x];
}

void pc_init_known_terrain(pc *p)
{
  uint32_t y, x;

  for (y = 0; y < DUNGEON_Y; y++)
  {
    for (x = 0; x < DUNGEON_X; x++)
    {
      p->known_terrain[y][x] = ter_unknown;
      p->visible[y][x] = 0;
    }
  }
}

void pc_observe_terrain(pc *p, dungeon *d)
{
  pair_t where;
  int16_t y_min, y_max, x_min, x_max;

  y_min = p->position[dim_y] - PC_VISUAL_RANGE;
  if (y_min < 0)
  {
    y_min = 0;
  }
  y_max = p->position[dim_y] + PC_VISUAL_RANGE;
  if (y_max > DUNGEON_Y - 1)
  {
    y_max = DUNGEON_Y - 1;
  }
  x_min = p->position[dim_x] - PC_VISUAL_RANGE;
  if (x_min < 0)
  {
    x_min = 0;
  }
  x_max = p->position[dim_x] + PC_VISUAL_RANGE;
  if (x_max > DUNGEON_X - 1)
  {
    x_max = DUNGEON_X - 1;
  }

  for (where[dim_y] = y_min; where[dim_y] <= y_max; where[dim_y]++)
  {
    where[dim_x] = x_min;
    can_see(d, p->position, where, 1, 1);
    where[dim_x] = x_max;
    can_see(d, p->position, where, 1, 1);
  }
  /* Take one off the x range because we alreay hit the corners above. */
  for (where[dim_x] = x_min - 1; where[dim_x] <= x_max - 1; where[dim_x]++)
  {
    where[dim_y] = y_min;
    can_see(d, p->position, where, 1, 1);
    where[dim_y] = y_max;
    can_see(d, p->position, where, 1, 1);
  }
}

int32_t is_illuminated(pc *p, int16_t y, int16_t x)
{
  return p->visible[y][x];
}

void pc_see_object(character *the_pc, object *o)
{
  if (o)
  {
    o->has_been_seen();
  }
}

int pc::pickup_object(dungeon *d)
{
  int counter;
  object *obj_ptr;
  if ((obj_ptr = d->objmap[d->PC->position[dim_y]][d->PC->position[dim_x]]) == NULL)
  {
    return 1;
  }
  for (counter = 0; counter < PC_BACKPACKSIZE; counter++)
  {
    if (backpack[counter] == NULL)
    {
      backpack[counter] = obj_ptr;
      d->objmap[d->PC->position[dim_y]][d->PC->position[dim_x]] = d->objmap[d->PC->position[dim_y]][d->PC->position[dim_x]]->next;
      backpack[counter]->next = NULL;
      if ((obj_ptr = d->objmap[d->PC->position[dim_y]][d->PC->position[dim_x]]) == NULL)
        return 0;
    }
  }
  return 2;
}

int pc::equip_object(int item_pos)
{
  int counter;
  object *obj_hold;
  if (backpack[item_pos] == NULL)
  {
    return 1;
  }
  if (backpack[item_pos]->get_type_str().find("RING") != std::string::npos)
  {
    return equip_ring(item_pos);
  }

  //Equip the item based on attr
  for (counter = 0; counter < TOTAL_EQUIPS; counter++)
  {
    //Special case for RING
    if (backpack[item_pos]->get_type_str().compare(equipable_lookup[counter].name) == 0)
    {
      if (equipped_items[counter] == NULL)
      {
        equipped_items[counter] = backpack[item_pos];
        backpack[item_pos] = NULL;
      }
      else
      {
        obj_hold = equipped_items[counter];
        equipped_items[counter] = backpack[item_pos];
        backpack[item_pos] = obj_hold;
      }
      update_speed();
      return 0;
    }
  }
  return 2;
}

int pc::unequip_object(int item_pos)
{
int counter;
  if (equipped_items[item_pos] == NULL)
  {
    return 1;
  }
  for (counter = 0; counter < PC_BACKPACKSIZE; counter++)
  {
    if (backpack[counter] == NULL)
    {
      backpack[counter] = equipped_items[item_pos];
      equipped_items[item_pos] = NULL;
      update_speed();
      return 0;
    }
  }
  return 2;
}

int pc::equip_ring(int item_pos)
{
  char *line;
  int input;
  object *obj_hold;
  line = (char *)malloc(5 * sizeof(char));
  mvprintw(PC_BACKPACKSIZE + MENU_HEIGHT_OFFSET + 2, MENU_WIDTH_OFFSET, " %-60s ", "Please enter 0 for Left Ring and 1 for Right Ring: ");
  getnstr(line, 5);
  try
  {
    input = std::stoi(line);
  }
  catch (...)
  {
    mvprintw(PC_BACKPACKSIZE + MENU_HEIGHT_OFFSET + 2, MENU_WIDTH_OFFSET, " %-80s ", "Invalid location start new command.");
    free(line);
    return 2;
  }
  free(line);
  if (input == 0)
  {
    if (equipped_items[location_LRING] == NULL)
    {
      equipped_items[location_LRING] = backpack[item_pos];
      backpack[item_pos] = NULL;
    }
    else
    {
      obj_hold = equipped_items[location_LRING];
      equipped_items[location_LRING] = backpack[item_pos];
      backpack[item_pos] = obj_hold;
    }
    update_speed();
    return 0;
  }
  else if (input == 1)
  {
    if (equipped_items[location_RRING] == NULL)
    {
      equipped_items[location_RRING] = backpack[item_pos];
      backpack[item_pos] = NULL;
    }
    else
    {
      obj_hold = equipped_items[location_RRING];
      equipped_items[location_RRING] = backpack[item_pos];
      backpack[item_pos] = obj_hold;
    }
    update_speed();
    return 0;
  }
  mvprintw(PC_BACKPACKSIZE + MENU_HEIGHT_OFFSET + 2, MENU_WIDTH_OFFSET, " %-60s ", "");
  return 2;
}

const char *get_equipable_loc_str(int pos)
{
  if (pos > TOTAL_EQUIPS)
    return "Out of range";
  return equipable_lookup[pos].name;
}

int pc::update_speed(){
  int spd = PC_SPEED;
  int count;
 for (count = 0; count < TOTAL_EQUIPS; count++)
    {
      if (equipped_items[count]){
        spd += equipped_items[count]->get_speed();
      }
    }
    if(spd > 0) this->speed = spd;
    else this->speed = 1;
    return this->speed;
}

int pc::get_atk_damage(){
  int damage = 0;
  int count;
  //If there is no weapon, use default damage dice and calculate rest of buff items.
  if(equipped_items[0] == NULL) damage = this->damage->roll();
  for (count = 0; count < TOTAL_EQUIPS; count++)
    {
      if (equipped_items[count]){
        damage += equipped_items[count]->roll_dice();;
      }
    }
    if(damage <= 0) damage = 0;
  return damage;
}